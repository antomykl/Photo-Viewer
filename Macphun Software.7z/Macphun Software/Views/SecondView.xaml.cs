﻿using System.Windows.Controls;

namespace Photoviewer.Views
{
    /// <summary>
    /// Логика взаимодействия для SecondView.xaml
    /// </summary>
    public partial class SecondView : UserControl
    {
        public SecondView()
        {
            InitializeComponent();
        }
    }
}
